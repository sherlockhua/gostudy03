package main

import (
	"github.com/gostudy03/day15/tcp_chat/protocal"
)

var (
	AllConfigRoomList []*protocal.Room
)

func init() {

	loveRoom := &protocal.Room{
		RoomId: 1,
		Name: "谈情说爱",
		RoomCap: 500,
		Desc: "",
		Online:0,
	}

	AllConfigRoomList = append(AllConfigRoomList, loveRoom)

	GoRoom := &protocal.Room{
		RoomId: 2,
		Name: "Go开发论坛",
		RoomCap: 500,
		Desc: "",
		Online:0,
	}

	AllConfigRoomList = append(AllConfigRoomList, GoRoom)

	JavaRoom := &protocal.Room{
		RoomId: 3,
		Name: "Java开发论坛",
		RoomCap: 500,
		Desc: "",
		Online:0,
	}

	AllConfigRoomList = append(AllConfigRoomList, JavaRoom)
}