package main

import (
	"github.com/gostudy03/xlog"
	"time"
	"net"
)

func main() {
	conn, err := net.Dial("tcp", "localhost:50000")
	if err != nil {
		xlog.LogError("Error dialing", err.Error())
		return
	}
	defer conn.Close()
	
	//1. 拉取房间列表
	xlog.LogDebug("start get room list\n")
	roomList, err := getRoomList(conn)
	if err != nil {
		xlog.LogError("get room list failed, err:%v", err)
		return
	}

	showRoomList(roomList)
	for {
		time.Sleep(time.Second)
	}
}
